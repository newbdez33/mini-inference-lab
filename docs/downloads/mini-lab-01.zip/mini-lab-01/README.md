# 跑通第一次模型推理

这是 Mini 的第一个模型推理实验：在自己的电脑上运行一个小模型，问它一个问题，再只换输入，看看回答怎么变。

**预计用时：10–15 分钟。** 包括阅读步骤和动手操作；首次安装 Python、安装依赖及下载模型的等待时间另计。

**本篇使用 Python 和 CPU，无需独立显卡。** 首次运行要联网下载依赖和模型，等待时间取决于设备与网络。命令块可以切换 macOS、Windows 和 Linux；切换一处，整页同步。Windows 请使用 PowerShell，macOS 和 Linux 使用终端。

<a id="download"></a>

## 01 · 下载并解压实验包

[下载 mini-lab-01.zip](https://github.com/newbdez33/mini-inference-lab/raw/refs/heads/main/packages/mini-lab-01.zip)

下载完成后，双击 ZIP 解压。包内已经有 `mini-lab-01` 文件夹，**不用自己新建目录，也不用自己写脚本或依赖清单**。

```text
mini-lab-01/
├── README.md
├── example_infer.py
├── requirements.txt
└── terminal-recordings.json
```

| 文件 | 你会用它做什么 |
| --- | --- |
| `README.md` | 当前这份操作说明，下载后也可以阅读。 |
| `example_infer.py` | 已写好的完整推理脚本，稍后直接运行。 |
| `requirements.txt` | 随实验包提供的依赖清单，用来安装指定版本的库。 |
| `terminal-recordings.json` | 本次实验保存的两个实际输入和回答，用来对照。 |

**完成检查：** 打开解压后的文件夹，能看到上面四个文件。

<a id="python"></a>

## 02 · 先确认 Python 能用

打开终端，选择自己的系统，运行：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
python3 --version
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
py -3 --version
```

</div>
</div>

本实验需要 **Python 3.11 或更新版本**。版本符合就可以继续，无需特地更换已有环境。这里是在检查电脑上已有的工具，还没有进入实验目录。

<details markdown="1">
<summary>找不到 Python，或版本太旧？</summary>

- **macOS：** 已有 Homebrew 时，可以执行 `brew install python`。没有 Homebrew 时，先按 [Homebrew 官方安装说明](https://docs.brew.sh/Installation)安装并完成 shell 配置，再重新打开终端。
- **Windows：** 按 [Python 官方 Windows 说明](https://docs.python.org/3/using/windows.html)安装 Python，然后重新打开 PowerShell。
- **Linux：** 按 [Python 官方 Unix 说明](https://docs.python.org/3/using/unix.html)和发行版文档安装 Python 及其 `venv` 支持。

也可以使用自己熟悉的 Python 管理工具。**重新运行上面的版本检查，确认符合要求后再继续。**

</details>

<a id="directory"></a>

## 03 · 在实验目录打开终端

如果 ZIP 下载并解压在默认的“下载”目录，执行下面的命令。解压在其他位置时，把第一行的目录替换成实际路径。

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
cd "$HOME/Downloads/mini-lab-01"
ls README.md example_infer.py requirements.txt
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
cd "$HOME\Downloads\mini-lab-01"
Get-ChildItem README.md, example_infer.py, requirements.txt
```

</div>
</div>

**完成检查：** 三个文件名都能列出，没有文件或路径不存在的报错。后面所有命令都在这个终端、这个目录里执行。

<a id="environment"></a>

## 04 · 准备实验环境

先给这个实验创建一个单独的 Python 环境：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
python3 -m venv .venv
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
py -3 -m venv .venv
```

</div>
</div>

接下来使用这个环境：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
source .venv/bin/activate
```

激活后，后续的 `python` 会使用这个环境。终端提示符通常会多出 `(.venv)`。

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
.\.venv\Scripts\python.exe --version
```

Windows 直接调用环境里的 Python，无需激活或修改 PowerShell 的执行策略。

</div>
</div>

安装实验包中列出的依赖：

<div class="platform-commands" markdown="1">
<div data-platforms="macos" markdown="1">

**macOS**

```sh
python -m pip install -r requirements.txt
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
.\.venv\Scripts\python.exe -m pip install torch==2.15.0 --index-url https://download.pytorch.org/whl/cpu
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

先安装 CPU 版 PyTorch，再安装其余依赖。

</div>
<div data-platforms="linux" markdown="1">

**Linux**

```sh
python -m pip install torch==2.15.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
```

先安装 CPU 版 PyTorch，再安装其余依赖。

</div>
</div>

等安装结束、终端重新出现提示符后，再检查两个主要库：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
python -c "import torch, transformers; print(torch.__version__); print(transformers.__version__)"
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
.\.venv\Scripts\python.exe -c "import torch, transformers; print(torch.__version__); print(transformers.__version__)"
```

</div>
</div>

**完成检查：** 能打印 PyTorch 和 Transformers 的版本号，没有导入错误。实验包固定使用 PyTorch 2.15.0、Transformers 5.22.1 和 Jinja2 3.1.6。

`requirements.txt` 就在当前目录中，安装命令会读取它。它不会被自动下载，也不需要你另行创建。

<a id="first-run"></a>

## 05 · 第一个实验：问模型一个小问题

运行刚才下载的完整脚本：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
python example_infer.py
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
.\.venv\Scripts\python.exe example_infer.py
```

</div>
</div>

看到 `Prompt:` 后，输入下面这句话，再按回车：

```text
请用一句话解释什么是人工智能。
```

脚本会加载 `Qwen/Qwen2.5-0.5B-Instruct`。第一次需要从 Hugging Face 下载模型；后续复用缓存。看到 `Loading` 或下载进度时，先等待，不要重复启动脚本。

模型加载好后会出现 `Generating...`，然后是 `Answer:`。这是我们实际运行得到的一次回答：

> 人工智能是一种模拟人类智能的理论与技术，能够使机器在执行任务时表现出与人类相似或超越人类的能力。它包括了机器学习、深度学习、自然语言处理等多个领域，并且正在逐渐渗透到我们的日常生活中。

这次模型写了两句话，没有完全遵循“一句话”的要求。这里保留原始回答，稍后再比较两次结果。

**完成检查：** 你的终端出现 `Answer:` 和一段非空文字，随后回到命令提示符。回答不必与这里逐字一致。

这个脚本每次只处理一个问题，然后退出。想再问一次，就再运行一次。

<a id="second-run"></a>

## 06 · 只换一个问题

仍然在同一个终端、同一个目录里，执行同一条命令：

<div class="platform-commands" markdown="1">
<div data-platforms="macos linux" markdown="1">

**macOS · Linux**

```sh
python example_infer.py
```

</div>
<div data-platforms="windows" markdown="1">

**Windows · PowerShell**

```powershell
.\.venv\Scripts\python.exe example_infer.py
```

</div>
</div>

这次在 `Prompt:` 后输入：

```text
用一句话介绍猫。
```

模型和生成设置都不改。我们实际得到的回答是：

> 猫，以其优雅的外表、温顺的性格和多才多艺的生活方式，成为了许多人喜爱的宠物之一。

对照两次结果：内容有没有跟着问题改变？有没有遵循“一句话”的要求？接着可以换一个你自己感兴趣的问题。

**这次实验完成的标志：同一个模型，两个输入，两次实际回答。**

<a id="code"></a>

## 07 · 再看刚才运行的脚本

现在打开实验包里的 `example_infer.py`。你已经运行过它了，只需要沿着问题走一遍下面三步。

1. **加载。** `AutoTokenizer.from_pretrained` 读取分词器，`AutoModelForCausalLM.from_pretrained` 加载模型。
2. **整理输入。** `apply_chat_template` 把问题按模型的对话格式整理成输入。
3. **生成并还原文字。** `model.generate` 生成新的编号；脚本去掉输入部分，再用 `tokenizer.decode` 转回文字。

本集不修改这些代码。先记住这条顺序：**问题 → 模型输入 → 生成结果 → 文字回答。**

这里使用 CPU、float32，关闭采样，最多生成 64 个新 token。每次运行都会重新加载模型。这次验证的是流程，不比较性能，也不保证两台电脑的输出逐字相同。

<a id="help"></a>

## 卡住时，从这里检查

| 看到的情况 | 下一步 |
| --- | --- |
| 找不到 `python3` 或 `py` 命令 | 回到“先确认 Python 能用”，安装并确认版本后再继续。 |
| `requirements.txt` 或脚本找不到 | 回到“在实验目录打开终端”，确认解压目录和文件名。不要新建空文件来绕过错误。 |
| `ModuleNotFoundError` | 回到“准备实验环境”，按当前系统的标签重新安装依赖，确保安装和运行使用同一个环境。 |
| 安装失败，或版本检查失败 | 先确认使用的是 `.venv` 中的 Python、版本符合上方要求，再检查网络和完整报错。 |
| 模型下载失败 | 检查能否访问模型页面，再运行同一条命令；已有缓存通常可以复用。 |
| 一直显示加载或下载进度 | 首次下载和 CPU 推理可能需要等待；没有报错时先让当前进程完成。 |
| 内存不足 | 关闭其他占用内存的程序后重试。 |
| 新开终端后命令失效 | 重新进入 `mini-lab-01`，再按“准备实验环境”中的步骤使用已有环境。 |

如果需要反馈问题，保留操作系统、Python 版本、执行的命令和完整报错；在 [仓库的 Issues](https://github.com/newbdez33/mini-inference-lab/issues) 中描述卡在哪一步。

<a id="other-systems"></a>
<a id="references"></a>

## 本次实验的依据

示例输出采集于 macOS、Apple Silicon、Python 3.12、CPU；本篇流程另用本机默认的 Python 3.14 验证通过。Windows、Linux 和 Intel Mac 尚未在本次实验中实测。Python 最低版本要求来自固定依赖的发布说明：[PyTorch](https://pypi.org/project/torch/2.15.0/)、[Transformers](https://pypi.org/project/transformers/5.22.1/)。

模型版本固定为 `7ae557604adf67be50417f59c2c2f167def9a775`。两次完整输入和输出保存在包内的 `terminal-recordings.json`；其中的进程耗时包含导入与加载，不是推理性能基准。

参考：[模型说明](https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct)、[Transformers 对话模板](https://huggingface.co/docs/transformers/main/en/chat_templating)、[PyTorch 安装说明](https://pytorch.org/get-started/locally/)。

下一次实验，再拆开看看一句话经过分词器后变成了什么。
